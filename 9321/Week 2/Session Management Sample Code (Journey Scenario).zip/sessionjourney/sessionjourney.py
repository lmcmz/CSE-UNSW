from flask import Flask, render_template, session, redirect, url_for, escape, request

import os, binascii

app = Flask(__name__)

app.secret_key = binascii.hexlify(os.urandom(24))

@app.route('/')
def index():
    session.clear()
    return render_template('welcome.html')

@app.route('/menu', methods=['GET', 'POST'])
def menu():
    if not session.get('journey'):
        session['journey'] = []

    return render_template('menu.html')



@app.route('/control', methods=['POST'])
def control():
    print('Inside control')
    print(session)
    print(request.form['place'])
    soFar = session['journey']
    soFar.append(request.form['place'])
    session['journey'] = soFar
    print(session)
    journey = session.get('journey')
    return render_template('sofar.html', soFar=journey)


# @app.route('/logout')
# def logout():
#    # remove the username from the session if it is there
#    session.pop('username', None)
#    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run()
