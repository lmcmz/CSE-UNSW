// hash.h ... interface to hash function
// part of SIMC signature files
// Hash function from PostgreSQL
// Editted by John Shepherd, September 2018

#ifndef HASH_H
#define HASH_H 1

#include "bits.h"

Word hash_any(char *, int);

#endif
